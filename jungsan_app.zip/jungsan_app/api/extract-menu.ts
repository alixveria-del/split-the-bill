import type { VercelRequest, VercelResponse } from "@vercel/node";

export default async function handler(req: VercelRequest, res: VercelResponse) {
  if (req.method !== "POST") return res.status(405).json({ error: "Method not allowed" });

  const { base64, mimeType } = req.body;
  if (!base64 || !mimeType) return res.status(400).json({ error: "Missing image data" });

  const apiKey = process.env.ANTHROPIC_API_KEY;
  if (!apiKey) return res.status(500).json({ error: "API key not configured" });

  try {
    const response = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "x-api-key": apiKey,
        "anthropic-version": "2023-06-01"
      },
      body: JSON.stringify({
        model: "claude-opus-4-5",
        max_tokens: 1000,
        messages: [{
          role: "user",
          content: [
            { type: "image", source: { type: "base64", media_type: mimeType, data: base64 } },
            { type: "text", text: `메뉴판 이미지에서 메뉴명과 가격을 추출하세요.
가격은 원 단위 정수로 변환하세요 (예: 17.0 → 17000, 8,500 → 8500).
JSON 배열만 반환하세요. 다른 텍스트나 마크다운 없이:
[{"name":"메뉴명","price":숫자}]` }
          ]
        }]
      })
    });

    if (!response.ok) {
      const err = await response.json();
      return res.status(response.status).json({ error: err.error?.message || "API error" });
    }

    const data = await response.json();
    const text = data.content.map((b: any) => b.text || "").join("").replace(/```[\w]*\n?|```/g, "").trim();
    const items = JSON.parse(text);
    return res.status(200).json({ items });
  } catch (e: any) {
    return res.status(500).json({ error: e.message });
  }
}
